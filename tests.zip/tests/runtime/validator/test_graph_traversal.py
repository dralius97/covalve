import pytest

from covalve.runtime.validator.graph_traversal import validate_graph


def test_validate_graph_accepts_linear_graph():
    schema = {
        "INITIAL": "START",
        "FINAL": "END",
        "states": {
            "START": {"transitions": {"NEXT": {"to": "MIDDLE"}}},
            "MIDDLE": {"transitions": {"NEXT": {"to": "END"}}},
            "END": {"transitions": {}},
        },
    }

    assert validate_graph(schema) is True


def test_validate_graph_rejects_missing_keys():
    with pytest.raises(ValueError, match="missing INITIAL or FINAL key"):
        validate_graph({"states": {}})


def test_validate_graph_rejects_unreachable_states():
    schema = {
        "INITIAL": "START",
        "FINAL": "END",
        "states": {
            "START": {"transitions": {"NEXT": {"to": "END"}}},
            "ISOLATED": {"transitions": {}},
            "END": {"transitions": {}},
        },
    }

    assert validate_graph(schema) is False
